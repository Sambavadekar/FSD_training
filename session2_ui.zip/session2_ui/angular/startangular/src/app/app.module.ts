import {AppComponent} from './components/app/app.component'
import {BrowserModule} from '@angular/platform-browser'
import {NgModule} from '@angular/core'
import {AccountsModule} from './accounts/accounts.module'
import {LayoutModule} from './layout/layout.module'
import {ConsoleLoggerService} from './services/consoleLogger.service'
import {ILogger} from './services/ILogger.service'
import {DevicesModule} from './devices/devices.module'

@NgModule({
    declarations:[AppComponent],
    bootstrap:[AppComponent],
    imports:[BrowserModule,AccountsModule,LayoutModule,DevicesModule],
    providers:[{provide:ILogger,useClass:ConsoleLoggerService}]
    //providers:[{provide:"logger",useClass:ConsoleLoggerService}]
})
export class AppModule{

}