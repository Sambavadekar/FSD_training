import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { FormsModule } from '@angular/forms';
import { FakeProxy } from './services/fake.proxy';
import {AccountsService} from './services/accounts.service'
import { ILogger } from '../services/ILogger.service';
import { ConsoleLoggerService } from '../services/consoleLogger.service';

@NgModule({
  declarations: [LoginComponent, SignupComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[LoginComponent,SignupComponent],
  providers:[{provide:'accountsbaseUrl',useValue:"http://localhost:3000/accounts"},
  {provide:'accountsproxy',useClass:FakeProxy},
  {provide:AccountsService,useClass:AccountsService}]
  // {provide:ILogger,useClass:ConsoleLoggerService}]
})
export class AccountsModule { }
