import { Inject, Injectable } from '@angular/core';
import { ILogger } from 'src/app/services/ILogger.service';

@Injectable()
export class FakeProxy{
    constructor(@Inject('accountsbaseUrl') public url:String,public logger: ILogger){

    }
    post(path,data,callback){
        //debugger;
        this.logger.write(`${data} posted - ${this.url}/${path}`)
        setTimeout(()=> {
            callback("valid")
        },2000)
    }
}