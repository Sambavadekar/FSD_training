import {Component} from '@angular/core'

@Component({
    templateUrl:'./app.component.html',
    selector:'app-comp'
})
export class AppComponent{
    
}