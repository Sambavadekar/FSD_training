export abstract class ILogger {
    abstract write(msg):void;
}