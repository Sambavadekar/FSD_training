import { Inject, Injectable } from '@angular/core';
import {ILogger} from './ILogger.service'

//@Injectable()
export class ConsoleLoggerService extends ILogger{
    write(msg){
        console.log(msg);
    }
}
