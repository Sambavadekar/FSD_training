import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviceAdminPanelComponent } from './components/device-admin-panel/device-admin-panel.component';
import { AddDeviceComponent } from './components/add-device/add-device.component';
import { DeviceListComponent } from './components/device-list/device-list.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [DeviceAdminPanelComponent, AddDeviceComponent, DeviceListComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[DeviceAdminPanelComponent]
})
export class DevicesModule { }
