import { Component, OnInit, EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-add-device',
  templateUrl: './add-device.component.html',
  styleUrls: ['./add-device.component.css']
})
export class AddDeviceComponent implements OnInit {
  deviceID;
  deviceName;
  constructor() { }

  ngOnInit() {
  }

  @Output()
  onNewDevice=new EventEmitter<any>();

  onAddDevice(){
    //debugger;
    let device={deviceID:this.deviceID,deviceName:this.deviceName}
    this.onNewDevice.emit(device);
  }
}
