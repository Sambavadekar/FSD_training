import React from 'react';
const context={store:{key:'value'}};

function Appa(props){
    return(
    <h1>{props.store.key}</h1>
    )
}

function Root(props){
    return(
        <Appa store={props.store}/>
    )
}

//HOC
const ContextProvider=context=>Component=>{
    class ContainerComponent extends React.Component {
        render(){
            return(
                <Component {...context} />
            )
        }
    }
    return ContainerComponent
}

export const DecoratedRoot = ContextProvider(context)(Root);

//ReactDOM.render(<Root store={context.store}/>, document.getElementById('root'))