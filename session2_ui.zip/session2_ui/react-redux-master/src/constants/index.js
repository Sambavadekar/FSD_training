export const TASK_STATUSES = ['Unstarted', 'In Progress', 'Completed'];
