export const DeviceStoreActions={
    ADD_NEW_DEVICE:"ADD_NEW_DEVICE"
}