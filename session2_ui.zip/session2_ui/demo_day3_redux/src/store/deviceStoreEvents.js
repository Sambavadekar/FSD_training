export const DeviceStoreEvents = {
    OnNewDeviceAdded:"New Device Added"
}