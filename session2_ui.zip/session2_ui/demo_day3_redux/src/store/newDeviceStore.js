import FLUX from '../pic-flux';
import {DeviceStoreActions} from './deviceStoreActions';
import {DeviceStoreEvents} from './deviceStoreEvents';

let deviceStore = FLUX.createStore("devicestore");

//Data
let devices=[];

deviceStore.dispatcherCallback=function(action) {
    switch(action.actionName) {
        case DeviceStoreActions.ADD_NEW_DEVICE:
            devices.push(action.data)
            deviceStore.notifyAll(DeviceStoreEvents.OnNewDeviceAdded);
            break;
    }
}

deviceStore.getState=function(){
    return [...devices];
}
FLUX.getDispatcher().register(deviceStore.dispatcherCallback)