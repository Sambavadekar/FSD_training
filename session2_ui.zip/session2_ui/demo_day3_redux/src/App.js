import React from 'react';
//import logo from './logo.svg';
import './App.css';
import {DevicesModule} from './devices/devices.module'
function App(props) {
  //let devices = [{DeviceID:12,DeviceName:"sad",Status:"ha"},{DeviceID:123,DeviceName:"adfs",Status:"sfdvdfv"},{DeviceID:23432,DeviceName:"zvdsz",Status:"vmghm"}]
  return (
    <div className="App">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
      <DevicesModule.components.DeviceAdminPanel flux={props.flux}/>
    </div>
  );
}

export default App;