import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import FLUX from './pic-flux'
import {ReduxAppComponent} from './redux/redux.app'
import AppStore from './redux/appStore'
import deviceReducer from './redux/devicereducer'
import { createStore } from 'redux'
import {Provider} from 'react-redux'

//const store = new AppStore({devices:[]},deviceReducer)
const store = new createStore(deviceReducer,{devices:[]});

//ReactDOM.render(<ReduxAppComponent store={store}/>, document.getElementById('root'));

ReactDOM.render(<Provider store={store}>
    <ReduxAppComponent/>
    </Provider>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
