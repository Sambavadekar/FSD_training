import {DispatcherInstance} from './defaultDispatcher'
import MicroEvent from './microevents'
class PICFlux{
    _stores;
    _dispatcher;

    constructor(){
        this._stores={};
        this._dispatcher = DispatcherInstance
    }

    getStore(name){
        return this._stores[name]
    }
    createStore(name) {
        this._stores[name] = MicroEvent.mixin({})
        return this._stores[name]
    }
    registerDispatcher(dispatcherInstance){
        this._dispatcher = dispatcherInstance
    }
    getDispatcher(){
        return this._dispatcher
    }

    createAction(name,payload){
        return {actionName:name,data:payload}
    }
}

export default new PICFlux();