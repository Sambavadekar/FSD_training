import {DeviceStoreActions} from '../store/deviceStoreActions'
function ActionCreators() {

}
ActionCreators.prototype.addNewDevice = function(device) {
    console.log("add action called")
    return {
      type: DeviceStoreActions.ADD_NEW_DEVICE,
      text: device
    }
}

export default new ActionCreators()