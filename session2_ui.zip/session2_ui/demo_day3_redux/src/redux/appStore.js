function AppStore(initialState,reducer){
    this.state=initialState
    this.reducer=reducer
    this.viewcallbacks=[];
}
AppStore.prototype.subscribe=function(viewcallback){
    this.viewcallbacks.push(viewcallback)
}

AppStore.prototype.getState=function(){
    return this.state
}

AppStore.prototype.dispatch=function(action){
    this.state = this.reducer(this.state,action)
    this.viewcallbacks.forEach((callback)=>{
        callback()
    })
}

export default AppStore;