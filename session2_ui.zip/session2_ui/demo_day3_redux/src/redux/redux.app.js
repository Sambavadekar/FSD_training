import React from 'react';
import {connect} from 'react-redux'
import {DeviceAdminPanelComponent} from '../devices/components/deviceadminpanel/DeviceAdminPanelComponent'
import ActionCreators from '../redux/actionCreators'
class ReduxAppComponent extends React.Component {
    constructor(props) {
        super(props)
    }

    onNewDeviceHandler(device){
        this.props.dispatch(ActionCreators.addNewDevice(device))
    }

    render(){
        //return(<DeviceAdminPanelComponent store={this.props.store} />) //Old way without react redux
        return(<DeviceAdminPanelComponent devices={this.props.devices} onNewDeviceAdd={this.onNewDeviceHandler}/>)
    }
}

function mapStateToProps(state) {
    return {
        devices: state.devices
    }
}

export const ReduxAppComponentContainer=connect(mapStateToProps)(ReduxAppComponent);