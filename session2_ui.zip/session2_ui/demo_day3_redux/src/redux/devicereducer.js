import {DeviceStoreActions} from '../store/deviceStoreActions'
function deviceReducer(state,action){
    //debugger;
    switch(action.type){
        case DeviceStoreActions.ADD_NEW_DEVICE:
            let devices=[...state.devices]
            devices.push(action.text)
            let newState={...state,devices:devices}
            return newState
            break;
        default:return state;
    }
}

export default deviceReducer