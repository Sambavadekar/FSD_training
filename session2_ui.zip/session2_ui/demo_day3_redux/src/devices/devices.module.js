import {DeviceRowComponent} from './components/devicerow/DeviceRowComponent'
import {DeviceTableComponent} from './components/devicetable/DeviceTableComponent'
import {AddDeviceComponent} from './components/adddevice/AddDeviceComponent'
import {DeviceAdminPanelComponent} from './components/deviceadminpanel/DeviceAdminPanelComponent'

export const DevicesModule= {
    components:{
        DeviceRow:DeviceRowComponent,
        DeviceTable:DeviceTableComponent,
        AddDevice:AddDeviceComponent,
        DeviceAdminPanel:DeviceAdminPanelComponent
    }
};