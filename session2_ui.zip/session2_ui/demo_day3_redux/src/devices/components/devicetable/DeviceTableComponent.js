import React from 'react'
import {DevicesModule} from '../../devices.module'
export class DeviceTableComponent extends React.Component{
    constructor(props) {
        super(props);
    }

    render(){
        //debugger;
        //console.log("render called"+ this.props.devices)
        let deviceComponentArray=[];
        for(let i=0;i<this.props.devices.length;i++){
            deviceComponentArray.push(
                <DevicesModule.components.DeviceRow item={this.props.devices[i]} key={i}/>
            )
        }
        return(
            <table>
                <thead>
                    <tr>
                        <td>ID</td>
                        <td>Name</td>
                        <td>Status</td>
                    </tr>
                </thead>
                <tbody>{deviceComponentArray}</tbody>
            </table>
        )
        
    }
}