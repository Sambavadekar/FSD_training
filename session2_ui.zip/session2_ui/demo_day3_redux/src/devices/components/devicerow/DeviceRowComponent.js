import React from 'react'
export const DeviceRowComponent=(props)=> {
    //console.log(props)
    return (
        <tr>
            <td>{props.item.DeviceID}</td>
            <td>{props.item.DeviceName}</td>
            <td>{props.item.Status}</td>
            <td>
                <button>Select</button>
            </td>
        </tr>
    );
};