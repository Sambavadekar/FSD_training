import React from 'react'
import autobind from 'react-autobind'

export class AddDeviceComponent extends React.Component{
    device = {};
    constructor(props) {
        super(props);
        this.device = {}
        this.state={stateErrorMessage:""}
        autobind(this)
    }

    onAddDevice_Button_Click = () => {
        //Lifting state up
        this.props.onNewDeviceAdded({...this.device}) //... or spread helps clone
    }

    onDeviceID_Change = (evt) => {
        this.device.DeviceID = evt.target.value
    }

    onDeviceName_Change = (evt) => {
        this.device.DeviceName = evt.target.value
    }

    //@autobind // some sort of bind needed to acces this
    onStatus_Change(evt){
        this.device.Status = evt.target.value
    }

    handleFormSubmit(evt) {
        evt.preventDefault();
        var formData = new FormData(evt.target);
        var device = {
            DeviceID:formData.get("idEditControl"),
            DeviceName:formData.get("nameEditControl"),
            Status:formData.get("statusEditControl"),
            Blah:this.refs.deviceIDRef.value //Prohibitted
        }
        var newState = {}
        if (device.Status.toLowerCase() != "connected" && device.Status.toLowerCase() != "disconnected") {
            newState = {...this.state,stateErrorMessage:"state is wrong man"};
        }else {
            newState = {...this.state,stateErrorMessage:""};
            this.props.onNewDeviceAdded(device);
        }
        this.setState(newState)
        console.log(device.Blah)
    }

    render(){
        return(
            <fieldset>
                <legend>Add new device</legend>
                <table>
                    <tbody>
                    <tr>
                        <td>ID</td>
                        <td><input type="text" onChange={this.onDeviceID_Change}/></td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" onChange={this.onDeviceName_Change}/></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td><input type="text" onChange={this.onStatus_Change}/></td>
                        <td><output></output></td>
                    </tr>
                    <tr>
                        <td><button onClick={this.onAddDevice_Button_Click}>Add</button></td>
                    </tr>
                    </tbody>
                </table>
                <form onSubmit={this.handleFormSubmit}>
                    <table>
                        <tbody>
                        <tr>
                            <td>ID</td>
                            <td><input type="text" name="idEditControl" ref="deviceIDRef"/></td>
                        </tr>
                        <tr>
                            <td>Name</td>
                            <td><input type="text" name="nameEditControl"/></td>
                        </tr>
                        <tr>
                            <td>Status</td>
                            <td><input type="text" name="statusEditControl"/></td>
                            <td><output name="statusErrorControl">{this.state.stateErrorMessage}</output></td>
                        </tr>
                        <tr>
                            <td><button type="submit">Add</button></td>
                        </tr>
                        </tbody>
                    </table>
                </form>
            </fieldset>
        )
        
    }
}