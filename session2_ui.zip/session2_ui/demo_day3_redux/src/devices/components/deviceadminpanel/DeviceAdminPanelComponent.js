import React from 'react'
import {DevicesModule} from '../../devices.module'
import {DeviceStoreActions} from '../../../store/deviceStoreActions'
import ActionCreators from '../../../redux/actionCreators'

export class DeviceAdminPanelComponent extends React.Component {
    //deviceList;
    constructor(props) {
        super(props);
        //deviceList = []
        this.state={deviceList:[]}
    }

    onNewDeviceAdded = (device) => {

        //this.props.store.dispatch({type:DeviceStoreActions.ADD_NEW_DEVICE,text:device});
        //this.props.store.dispatch(ActionCreators.addNewDevice(device)) //before react redux
        this.props.onNewDeviceAdd(device)
    }

    componentDidMount() {

        this.props.store.subscribe(()=>{
            //debugger;
            let devices = [...this.props.store.getState().devices]
            let newState = {...this.state,deviceList:devices}; 
            this.setState(newState)
            console.log("subscription to add called via flux using redux")
        })
    }

    render() {
        return(
            <div>
                <DevicesModule.components.AddDevice onNewDeviceAdded={this.onNewDeviceAdded}/>
                <DevicesModule.components.DeviceTable devices={this.state.deviceList}/>
            </div>
        )
    }
}

/* Learn
let x = ['a','b','c'];
undefined
console.log(x)
VM3113:1 (3) ["a", "b", "c"]
undefined
let y = [...x];
undefined
console.log(y)
VM3173:1 (3) ["a", "b", "c"]
undefined
let state={ylist:x,tets:100,key:'test'}
undefined
console.log(state)
VM3323:1 {ylist: Array(3), tets: 100, key: "test"}key: "test"tets: 100ylist: (3) ["a", "b", "c"]__proto__: Object
undefined
y.push('dd')
4
console.log(state)
VM3372:1 {ylist: Array(3), tets: 100, key: "test"}
undefined
let newstate={...state,ylist:y}
undefined
console.log(newstate)
VM3506:1 {ylist: Array(4), tets: 100, key: "test"}key: "test"tets: 100ylist: (4) ["a", "b", "c", "dd"]__proto__: Object
undefined
let newstate={...newstate,ylist:x}
VM3522:1 Uncaught SyntaxError: Identifier 'newstate' has already been declared
    at <anonymous>:1:1
(anonymous) @ VM3522:1
let newstate1={...newstate,ylist:x}
undefined
console.log(newstate1)
VM3542:1 {ylist: Array(3), tets: 100, key: "test"}
undefined
*/