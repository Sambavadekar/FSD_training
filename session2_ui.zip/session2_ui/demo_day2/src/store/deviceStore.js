import {DispatcherInstance} from '../flux/dispatcher'

function DeviceStore(){
    this._devices=[]
    this._viewCallbacks=[];
}

let dispatcherCallback=function(action) {
    //debugger;
    switch(action.actionName){
        case "ADD_NEW_DEVICE":
            this._devices.push(action.data);
            this.notifyAll()
            break;
    }
}
DeviceStore.prototype.subscribe=function(viewCallback) {
    this._viewCallbacks.push(viewCallback)
}

let notifyAll=function() {
    this._viewCallbacks.forEach(callback=> {
        callback()
    })
}

let getState=function(){
    return [...this._devices]
}

const deviceStoreInstance = new DeviceStore();

DeviceStore.prototype.dispatcherCallback = dispatcherCallback.bind(deviceStoreInstance)
DeviceStore.prototype.notifyAll = notifyAll.bind(deviceStoreInstance)
DeviceStore.prototype.getState = getState.bind(deviceStoreInstance)
//All above can be avoided with below
//DispatcherInstance.register(deviceStoreInstance.dispatcherCallback.bind(deviceStoreInstance))
DispatcherInstance.register(deviceStoreInstance.dispatcherCallback)


export default deviceStoreInstance;