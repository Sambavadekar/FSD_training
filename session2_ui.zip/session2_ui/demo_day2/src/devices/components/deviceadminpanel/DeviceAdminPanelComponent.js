import React from 'react'
import {DevicesModule} from '../../devices.module'
import {DispatcherInstance} from '../../../flux/dispatcher'
import DeviceStoreInstance from '../../../store/deviceStore'
import {DeviceStoreActions} from '../../../store/deviceStoreActions'
import {DeviceStoreEvents} from '../../../store/deviceStoreEvents'

export class DeviceAdminPanelComponent extends React.Component {
    //deviceList;
    constructor(props) {
        super(props);
        //deviceList = []
        this.state={deviceList:[]}
    }

    onNewDeviceAdded = (device) => {
        //debugger;
        // let deviceList=[...this.state.deviceList];
        // deviceList.push(device);
        // let newState = {...this.state,deviceList:deviceList}; //modifying only value for one key, always ...state at first, else its over written

        // this.setState(newState)
        // console.log("add called")

        // let actionObj = { //Old style witout pic flux
        //     actionName:"ADD_NEW_DEVICE",data:device
        // }

        //DispatcherInstance.dispatch(actionObj)

        let actionObj = this.props.flux.createAction(DeviceStoreActions.ADD_NEW_DEVICE,device);
        this.props.flux.getDispatcher().dispatch(actionObj)
    }

    componentDidMount() {
        debugger;
        let storeRef = this.props.flux.getStore("devicestore");

        storeRef.subscribe(DeviceStoreEvents.OnNewDeviceAdded, ()=>{
            //debugger;
            let devices = storeRef.getState()
            let newState = {...this.state,deviceList:devices}; 
            this.setState(newState)
            console.log("subscription to add called via flux")
        })
    }

    // componentDidMountOld() { //Without using flux pic
    //     DeviceStoreInstance.subscribe(()=>{
    //         //debugger;
    //         let devices = DeviceStoreInstance.getState()
    //         let newState = {...this.state,deviceList:devices}; 
    //         this.setState(newState)
    //         console.log("subscription to add called")
    //     })
    // }

    render() {
        return(
            <div>
                <DevicesModule.components.AddDevice onNewDeviceAdded={this.onNewDeviceAdded}/>
                <DevicesModule.components.DeviceTable devices={this.state.deviceList}/>
            </div>
        )
    }
}

/* Learn
let x = ['a','b','c'];
undefined
console.log(x)
VM3113:1 (3) ["a", "b", "c"]
undefined
let y = [...x];
undefined
console.log(y)
VM3173:1 (3) ["a", "b", "c"]
undefined
let state={ylist:x,tets:100,key:'test'}
undefined
console.log(state)
VM3323:1 {ylist: Array(3), tets: 100, key: "test"}key: "test"tets: 100ylist: (3) ["a", "b", "c"]__proto__: Object
undefined
y.push('dd')
4
console.log(state)
VM3372:1 {ylist: Array(3), tets: 100, key: "test"}
undefined
let newstate={...state,ylist:y}
undefined
console.log(newstate)
VM3506:1 {ylist: Array(4), tets: 100, key: "test"}key: "test"tets: 100ylist: (4) ["a", "b", "c", "dd"]__proto__: Object
undefined
let newstate={...newstate,ylist:x}
VM3522:1 Uncaught SyntaxError: Identifier 'newstate' has already been declared
    at <anonymous>:1:1
(anonymous) @ VM3522:1
let newstate1={...newstate,ylist:x}
undefined
console.log(newstate1)
VM3542:1 {ylist: Array(3), tets: 100, key: "test"}
undefined
*/