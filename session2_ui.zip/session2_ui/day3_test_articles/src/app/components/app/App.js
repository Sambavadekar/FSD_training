import React from 'react';
import {ArticleDisplayModule} from '../../../articleDisplay/articleDisplay.module'
import deviceReducer from '../../../redux/articleReducer'
import { createStore } from 'redux'
import './App.css';
function App(props) {
  const store = new createStore(deviceReducer,{articles:[]});
  return (
    <ArticleDisplayModule.components.ArticleContainer store={store} />
  )
}

export default App;
