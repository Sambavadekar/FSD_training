import {ArticleEntryFormComponent} from './components/articleEntryForm/ArticleEntryForm'

export const ArticleEntryModule= {
    components:{
        ArticleEntryForm:ArticleEntryFormComponent
    }
};