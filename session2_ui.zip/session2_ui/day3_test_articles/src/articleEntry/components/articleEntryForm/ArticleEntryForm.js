import React from 'react'
import autobind from 'react-autobind'

export class ArticleEntryFormComponent extends React.Component{
    constructor(props) {
        super(props);
        this.state={titleErrorMessage:""}
        autobind(this)
    }

    handleFormSubmit(evt) {
        evt.preventDefault();
        var formData = new FormData(evt.target);
        var article = {
            title:formData.get("titleEditControl"),
            description:formData.get("descriptionEditControl"),
            content:formData.get("contentEditControl")
        }
        var newState = {}
        if (article.title == "") {
            newState = {...this.state,titleErrorMessage:"title is wrong man"};
        }else {
            newState = {...this.state,titleErrorMessage:""};
            this.props.onNewDeviceAdded(article);
        }
        this.setState(newState)
    }

    render(){
        return(
            <fieldset>
                <legend>Add new device</legend>
                <form onSubmit={this.handleFormSubmit}>
                    <table>
                        <tbody>
                        <tr>
                            <td>Title</td>
                            <td><input type="text" name="titleEditControl"/></td>
                        </tr>
                        <tr>
                            <td>Description</td>
                            <td><input type="text" name="descriptionEditControl"/></td>
                        </tr>
                        <tr>
                            <td>Content</td>
                            <td><textarea name="contentEditControl"></textarea></td>
                            <td><output >{this.state.titleErrorMessage}</output></td>
                        </tr>
                        <tr>
                            <td><button type="submit">Add</button></td>
                        </tr>
                        </tbody>
                    </table>
                </form>
            </fieldset>
        )
        
    }
}