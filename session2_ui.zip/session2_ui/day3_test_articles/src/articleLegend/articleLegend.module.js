import {ArticleLegendComponent} from './components/articleLegend/ArticleLegend'

export const ArticleLegendModule= {
    components:{
        ArticleLegend:ArticleLegendComponent
    }
};