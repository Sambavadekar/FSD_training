import React from 'react'
export const ArticleLegendComponent=(props)=> {
    //console.log(props)
    return (
        <fieldset>
            <legend>Legend</legend>
            <p>{props.count}</p>
        </fieldset>
    );
};