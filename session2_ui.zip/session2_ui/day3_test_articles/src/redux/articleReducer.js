import {ArticleStoreActions} from './articleStoreActions'
function articleReducer(state,action){
    //debugger;
    switch(action.type){
        case ArticleStoreActions.ADD_NEW_ARTICLE:
            let articles=[...state.articles]
            articles.push(action.text)
            let newState={...state,articles:articles}
            return newState
            break;
        default:return state;
    }
}

export default articleReducer