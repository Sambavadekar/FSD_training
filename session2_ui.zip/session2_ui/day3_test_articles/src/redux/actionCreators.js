import {ArticleStoreActions} from '../redux/articleStoreActions'
function ActionCreators() {

}
ActionCreators.prototype.addNewArticle= function(article) {
    //console.log("add action called")
    return {
      type: ArticleStoreActions.ADD_NEW_ARTICLE,
      text: article
    }
}

export default new ActionCreators()