export const ArticleStoreActions={
    ADD_NEW_ARTICLE:"ADD_NEW_ARTICLE"
}