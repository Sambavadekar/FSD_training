import React from 'react'
import {ArticleDisplayModule} from '../../articleDisplay.module'
import './ArticleTable.css';
export class ArticleTableComponent extends React.Component{
    constructor(props) {
        super(props);
    }

    render(){
        //debugger;
        let articleComponentArray=[];
        for(let i=0;i<this.props.articles.length;i++){
            articleComponentArray.push(
                <ArticleDisplayModule.components.ArticleRow item={this.props.articles[i]} key={i}/>
            )
        }
        return(
            <fieldset>
                <legend>Articles</legend>
                <table className="table">
                    <tbody>{articleComponentArray}</tbody>
                </table>
            </fieldset>
        )
        
    }
}