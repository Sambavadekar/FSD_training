import React from 'react'
import './ArticleRow.css';
export const ArticleRowComponent=(props)=> {
    //console.log(props)
    return (
        <tr className="row">
            <td>
                <fieldset>
                    <legend>{props.item.title}</legend>
                    <p>{props.item.description}</p>
                    <p>{props.item.content}</p>
                </fieldset>
            </td>
        </tr>
    );
};