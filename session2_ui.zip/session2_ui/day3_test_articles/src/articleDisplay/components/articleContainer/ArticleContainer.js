import React from 'react'
import {ArticleDisplayModule} from '../../articleDisplay.module'
import {ArticleEntryModule} from '../../../articleEntry/articleEntry.module'
import {ArticleLegendModule} from '../../../articleLegend/articleLegend.module'
import ActionCreators from '../../../redux/actionCreators'

export class ArticleContainerComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state={articleList:[]}
    }

    onNewDeviceAdded = (article) => {
        this.props.store.dispatch(ActionCreators.addNewArticle(article))
    }

    componentDidMount() {

        this.props.store.subscribe(()=>{
            let articles = [...this.props.store.getState().articles]
            let newState = {...this.state,articleList:articles}; 
            this.setState(newState)
            console.log("subscription to add called via flux using redux")
        })
    }

    render() {
        return(
            <div className="mainContainer">
                <div id="leftPane">
                    <ArticleLegendModule.components.ArticleLegend count={this.state.articleList.length} />
                </div>
                <div id="middlePane">
                    <ArticleDisplayModule.components.ArticleTable articles={this.state.articleList} />
                </div>
                <div id="rightPane">
                    <ArticleEntryModule.components.ArticleEntryForm onNewDeviceAdded={this.onNewDeviceAdded}/>
                </div>
            </div>
        )
    }
}