import {ArticleRowComponent} from './components/articleRow/ArticleRow'
import {ArticleTableComponent} from './components/articleTable/ArticleTable'
import {ArticleContainerComponent} from './components/articleContainer/ArticleContainer'

export const ArticleDisplayModule= {
    components:{
        ArticleRow:ArticleRowComponent,
        ArticleTable:ArticleTableComponent,
        ArticleContainer:ArticleContainerComponent
    }
};