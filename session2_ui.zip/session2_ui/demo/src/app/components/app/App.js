import React from 'react';
import {layoutModule} from '../../../layout/layout.module'
import {vitalsModule} from '../../../vitals/vitals.module'
// import logo from './logo.svg';
import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

function App(props) {
  return (
    <React.Fragment>
      <div id="header">
        <layoutModule.components.Header title={props.title}/>
      </div>
      <div id="nav">
        <layoutModule.components.Nav/>
      </div>
      <div id="content" >
        <vitalsModule.components.SPO/>
      </div>
      <div id="footer">
        <layoutModule.components.Footer title="Philips NV."/>
      </div>
    </React.Fragment>
  )
}

export default App;
