import AppComponent from './components/app/App'

export const appModule= {
    components:{
        App:AppComponent
    }
};