import add, {sub} from './moduleA'
import * as moduleB from '/.moduleA'

console(moduleB)
sub(3,5)