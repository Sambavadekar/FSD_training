import HeaderComponent from './components/header/header'
import FooterComponent from './components/footer/footer'
import NavComponent from './components/nav/nav'
import {OutputComponent} from './components/output/output'
export const layoutModule= {
    components:{
        Header:HeaderComponent,
        Footer:FooterComponent,
        Nav:NavComponent,
        Output:OutputComponent
    }
};