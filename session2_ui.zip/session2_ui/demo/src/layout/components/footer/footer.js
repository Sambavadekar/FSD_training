import React from 'react';

export default class FooterComponent extends React.Component {
    render(){
        return (
            <h1>Copyright <br/>{this.props.title}</h1>
        )
    }
}