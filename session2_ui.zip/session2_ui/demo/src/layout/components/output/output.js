import React from 'react';
export function OutputComponent(props) {
    return(
    <output>{props.content}</output>
    );
}