import React from 'react';

export default class NavComponent extends React.Component {
    render(){
        return (
            <React.Fragment>
                <a href="#">BP</a><br/>
                <a href="#">Pulse</a><br/>
                <a href="#">SPO2</a><br/>
                <a href="#">Glucose</a><br/>
            </React.Fragment>
        )
    }
}