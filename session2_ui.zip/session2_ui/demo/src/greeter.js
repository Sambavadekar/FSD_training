class GreeterComponent {
    render() {
        return(<div>Blah blah</div>);
    }
}
export default GreeterComponent;