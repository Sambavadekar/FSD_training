import SPOComponent from './components/spo/spo'
export const vitalsModule= {
    components:{
        SPO:SPOComponent
    }
};