import React from 'react';
import {layoutModule} from '../../../layout/layout.module'

export default class SPOComponent extends React.Component {

    timerRef;
    blah;
    constructor(props) {
        super(props);
        this.state={spoCurrentValue:0}
    }

    componentDidMount(){
        
        this.timerRef = setInterval(()=>{
            this.setState({spoCurrentValue: Math.floor((Math.random() * 100) + 1)});
            this.blah = Math.random()
            //console.log(this.state.spoCurrentValue )
        },1000)
    }

    componentWillUnmount() {
        clearInterval(this.timerRef)
    }

    render(){
        return (
            <div>
                <h5>SPO monitoring value</h5>
                <p>Current SPO value {this.state.spoCurrentValue}</p>
                <layoutModule.components.Output content={this.state.spoCurrentValue}/>
                <p>Current blah value {this.blah}</p>
            </div>
        )
    }
}