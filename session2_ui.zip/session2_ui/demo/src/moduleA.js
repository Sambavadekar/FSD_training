function add(x,y) {
    return x+y;
}
export function sub(x,y) { //Named export
    return x-y;
}
export default add; //Default export