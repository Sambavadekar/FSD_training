import React from 'react';
import {createStore} from 'redux'
import {connect} from 'react-redux'

function AddTaskComponent(props){
  return(
    <div>
      {/* <input type="text" ref="input"/> */}
      {/* <button onClick={()=>{props.callbacktaskcontainer(props.refs.input.value)}}></button> */}
      <button onClick={()=>{props.callbacktaskcontainer({taskID:"100",name:'add'})}}>Add</button>
    </div>
  )
}

function TaskComponent(props){
  return(
    <div>
      <output>{props.task.taskID}</output>
    </div>
  )
}

function TaskListComponent(props){
  var i=0
  let taskComponents=props.tasks.map((task)=>{
    i++
    return <TaskComponent task={task} key={i}/>
  })
  return(
  <div>{taskComponents}</div>
  )
}

function TaskAppComponent(props) {
  function callback(task) {
    props.dispatch({type:"ADD_NEW_TASK",text:task})
  }
  return(
    <div>
      <AddTaskComponent callbacktaskcontainer={callback}></AddTaskComponent>
      <TaskListComponent tasks={props.tasks}></TaskListComponent>
    </div>
  )
}

//New

function AddUserComponent(props){
  return(
    <div>
      {/* <input type="text" ref="input"/> */}
      {/* <button onClick={()=>{props.callbacktaskcontainer(props.refs.input.value)}}></button> */}
      <button onClick={()=>{props.callbackusercontainer({userID:"user100",name:'add'})}}>Add</button>
    </div>
  )
}

function UserComponent(props){
  return(
    <div>
      <output>{props.user.userID}</output>
    </div>
  )
}

function UserListComponent(props){
  var i=0
  let userComponents=props.users.map((user)=>{
    i++
    return <UserComponent user={user} key={i}/>
  })
  return(
  <div>{userComponents}</div>
  )
}

function UserAppComponent(props) {
  function callback(user) {
    props.dispatch({type:"ADD_NEW_USER",text:user})
  }
  return(
    <div>
      <fieldset>
        <legend>Users</legend>
        <AddUserComponent callbackusercontainer={callback}></AddUserComponent>
        <UserListComponent users={props.users}></UserListComponent>
      </fieldset>
    </div>
  )
}

function reducer(state,action){
  switch(action.type){
    case "ADD_NEW_TASK":
      let tasks = [...state.tasks];
      tasks.push(action.text);
      return {...state,tasks:tasks};
      case "ADD_NEW_USER":
      let users = [...state.users];
      users.push(action.text);
      return {...state,users:users};
    default: return state;
  }
}

export const store = createStore(reducer,{tasks:[],users:[]});

function mapStateToTasksProps(state){
  return{
    tasks:state.tasks
  }
}
function mapStateToUsersProps(state){
  return{
    users:state.users
  }
}
export const TaskAppComponentBig=connect(mapStateToTasksProps)(TaskAppComponent);
export const UserAppComponentBig=connect(mapStateToUsersProps)(UserAppComponent);
