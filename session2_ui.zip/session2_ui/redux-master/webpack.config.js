module.exports = {
  entry: './app.js',
  output: {
    filename: './app.js'
  }
};
