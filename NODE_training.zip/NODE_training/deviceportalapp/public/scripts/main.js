(function(globalRef){
    globalRef.addEventListener("DOMContentLoaded",function(){
        console.log("DOMContentLoaded triggered")
        var loginButtonControl = globalRef.document.getElementById("loginButton");
        loginButtonControl.addEventListener("click", function(){
            console.log("login button clicked")
            var httpReq = new XMLHttpRequest();
            httpReq.open("GET","http://localhost:8002/components/login/login.html",true)

            httpReq.onreadystatechange=function(){
                if(httpReq.readyState==4){
                    if(httpReq.status == 200){
                        globalRef.document.getElementById("container").innerHTML = httpReq.response
                        var loginViewLoginButton= globalRef.document.getElementById("loginLoginButton");
                        loginViewLoginButton.addEventListener("click", function(){
                            var httpReq = new XMLHttpRequest();
                            httpReq.open("POST","http://localhost:8000/accounts/login",true)
                            httpReq.setRequestHeader("content-type","application/json");
                            var credentials = {
                                userName: globalRef.document.getElementById("loginUserNameCtrl").value,
                                password: globalRef.document.getElementById("passUserNameCtrl").value,
                            }
                            httpReq.onreadystatechange=function(){
                                if(httpReq.readyState==4){
                                    if(httpReq.status == 200){
                                        alert(httpReq.responseText)
                                    } else {
                                        alert("error"+ this.status)
                                    }
                                }
                            }
                            httpReq.send(JSON.stringify(credentials));
                        });

                        var loginViewSignUpButton= globalRef.document.getElementById("loginSignUpButton");
                        loginViewSignUpButton.addEventListener("click", function(){
                            var httpReq = new XMLHttpRequest();
                            httpReq.open("POST","http://localhost:8000/accounts/signup",true)
                            httpReq.setRequestHeader("content-type","application/json");
                            var credentials = {
                                userName: globalRef.document.getElementById("loginUserNameCtrl").value,
                                password: globalRef.document.getElementById("passUserNameCtrl").value,
                                email:"xyz@gmail.com"
                            }
                            httpReq.onreadystatechange=function(){
                                if(httpReq.readyState==4){
                                    if(httpReq.status == 200){
                                        alert(httpReq.responseText)
                                    } else {
                                        alert("error"+ this.status)
                                    }
                                }
                            }
                            httpReq.send(JSON.stringify(credentials));
                        });
                    }
                }
            };
            httpReq.send();
        })
    });
})(window)