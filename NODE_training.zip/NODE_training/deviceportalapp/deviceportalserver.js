const express=require('express')
const path = require('path')


const app=express()


// app.use(express.static(path.join(__dirname,'public')))
app.use(express.static(path.join(__dirname, 'public')))


app.use(function(req,res,next){
    res.send("Resource not found")
    console.log("resource not found")  
})
app.listen(8002, () => {
    console.log('devicePortalServer app listening on port 8002!')
  });