var userModel = require('./users.model');
function AccountsMongoRepository() {

}
AccountsMongoRepository.prototype.authenticate=function(userNAme,password,successcallback, failurecallback){
    let query = userModel.findOne()//{'name':userNAme,'password':password})
    console.log(userNAme + ' ' + password)
    query.exec(function(error,_users){
        console.log('query excecution success' + _users)
        if (_users) {
            successcallback(_users)
            return
        } else {
            failurecallback(error)
        }
    });
    
}
module.exports = new AccountsMongoRepository()