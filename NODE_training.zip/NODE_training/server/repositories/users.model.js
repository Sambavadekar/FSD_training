var mongoose = require('mongoose');
let Schema = mongoose.Schema;

let userSchema = new Schema({
    name:String,
    password:String,
    email:String
});

var users = mongoose.model("users_table", userSchema)

module.exports = users