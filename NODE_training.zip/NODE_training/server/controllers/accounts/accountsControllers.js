const accountRepository = require('../../repositories/mongoDBRepository')

function AccountsController(repository) {
    this._repository = repository
}

AccountsController.prototype.login = function(userName, password, successCallback, errorCallback) {
    // for(let index=0;index < this._userslist.length;index++) {
    //     if(this._userslist[index].userName === userName && this._userslist[index].password === password) {
    //         successCallback("valid credentials")
    //     }
    // }
    // errorCallback("Invalid credentials")
    console.log('before Login call')
    this._repository.authenticate(userName,password,
        (result) => {
            successCallback("valid credentials"+result)
            console.log('after Login call success')
        },
        (error) => {
            errorCallback("Invalid credentials" + (error || ""))
            console.log('after Login call failure')
        })
    return
}

AccountsController.prototype.signup = function(userName, password,email, successCallback, errorCallback) {
    this._userslist.push({userName:userName,password: password, email:email})
    successCallback("user signed up")
}

AccountsController.prototype.recoverPassword = function(userName,email) {
    
}

AccountsController.prototype.changePassword = function(userName,oldPassword, newPassword) {
    
}

module.exports = new AccountsController(accountRepository)