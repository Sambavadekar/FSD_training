const express = require('express')
var path = require('path');
const app = express();



app.use(function(req,res,next) {
  console.log("First Midleware")
  next()
})

app.use(function(req,res,next) {
  console.log("second Midleware")
  next()
})

app.use(function(req,res,next) {
  console.log("third Midleware")
  next()
})

app.use(express.static(path.join(__dirname, 'public')));

// app.get('/', (req, res) => {
//   res.send('Hello World!')
//   //console.log(req)
//   //console.log(console.log(req))
// });

// app.get('/index.html', (req, res) => {
    
// });

app.listen(8000, () => {
  console.log('Example app listening on port 8000!')
});