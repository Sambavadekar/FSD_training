var express = require('express');
var path = require('path');

var app2 = express();

//Static content handler(.html,.css,js,images)
app2.use(express.static(path.join(__dirname, 'public')));

app2.listen(3000, () => {
    console.log('Example app listening on port 8000!')
  });