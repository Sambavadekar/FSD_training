let express = require('express');
let router = express.Router();
let accountControllerInstance=require('../../../controllers/accounts/accountsControllers')

router.route("/login").post(function(req,res){
    let userName = req.body.userName;
    let password = req.body.password;
    console.log('login received')
    accountControllerInstance.login(userName,password,
        (result) => {
            res.status(200)
            res.send(result)
        },
        (error) => {
            res.status(200)
            res.send(error)
        })
})

router.route("/signup").post(function(req,res){
    let userName = req.body.userName;
    let password = req.body.password;
    let email = req.body.email;

    accountControllerInstance.signup(userName,password,email,
        (result) => {
            res.status(200)
            res.send(result)
        },
        (error) => {
            res.status(200)
            res.send(error)
        })
})

module.exports=router;