const express = require('express')
const mongoDBDriver = require('./repositories/mongoDBDriver')
const bodyparser = require('body-parser')
const cors = require('cors');

var path = require('path');

const app = express();

app.use(cors());
var accountsRouter = require('./api/routers/accounts');
app.use(express.json());
app.use('/accounts', accountsRouter);

app.listen(8000, () => {
  console.log('Example app listening on port 8000!')
});