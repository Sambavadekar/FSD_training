function Device() {
    console.log("device instantiated")
}
let obj = new Device();

//module.exports = new Device();