console.log("mvc loaded")

module.exports = {
    models:require('./models'),
    views:require('./views'),
    controller:require('./controllers'),
}