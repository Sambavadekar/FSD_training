function Parent(){
    this.pm = "Parent Member";
}
function Child(){
    this.cm = "Child Member";
    Parent.apply(this)
}

Parent.prototype.getPM = function() {
    console.log("Parent getPM")
}

Child.prototype.getCM = function() {
    console.log("child getCM")
}

Child.prototype.__proto__ = Parent.prototype

var child = new Child();
//child.__proto__ = new Parent()
console.log(child.pm)
console.log(child.cm)
child.getPM()
child.getCM()