//let appContents = require('./app'); //File or folder called app/app.js in the sepecified location
// let appContents = require('app'); //File or folder called app/app.js present inside node_modules
// let newtest = require('./newtest'); 
// console.log("Hello world")

// //let a = new appContents.AppConstructor()
// console.log(appContents)
// //a.greet()

// require('./cache'); 
// require('./cache'); 

// delete require.cache[require.resolve('./cache')]

// require('./cache'); 
// require('./cache'); 

let newtest = require('./inheritance'); 
let util = require('util')