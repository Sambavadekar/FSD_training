function App() {

}
App.prototype.greet=function() {
    console.log("Hello Node!!");
}

module.exports = {AppConstructor: App}