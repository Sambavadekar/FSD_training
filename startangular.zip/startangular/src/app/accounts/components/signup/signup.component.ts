import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  userName;
  password;
  email;
  errorMessage;
  constructor(public router:Router) {
    this.clear()
  }

  signup() {
    this.router.navigate(['main'])
  }
  
  clear(){
    this.userName = "";
    this.password = "";
    this.email= ""
    this.errorMessage = "";
  }
  ngOnInit() {
  }

}
