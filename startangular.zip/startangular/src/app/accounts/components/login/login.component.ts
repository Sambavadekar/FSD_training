import { Component, OnInit, Inject } from '@angular/core';
import { inject } from '@angular/core/testing';
import { ILogger } from 'src/app/services/ILogger.service';
import { AccountsService } from '../../services/accounts.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName:String;
  password:String;
  errorMessage:String;

  //constructor(@Inject('logger') public loggerService:any) {
  constructor(public loggerService:ILogger,public accoountsServiceRef:AccountsService,public router:Router) {
    this.clear()
  }

  onUserNameEdit(data){
    this.userName = data
  }
  onPasswordEdit(data){
    this.password = data
  }
  login(){
    //debugger;
    this.accoountsServiceRef.authenticate(this.userName,this.password,(result)=>{
      if(result == "valid"){
        //this.clear()
        this.loggerService.write(this.userName + "is correct")
        this.router.navigate(["home",this.userName])
      }else{
        this.errorMessage = "Invalid Yo"
      }
    })
    
  }

  clear(){
    this.userName = "";
    this.password = "";
    this.errorMessage = "";

  }
  ngOnInit() {
  }

}
