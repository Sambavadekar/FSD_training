import { Injectable, Inject } from '@angular/core'

//@Injectable
export class AccountsService{
    constructor(@Inject('accountsproxy') public proxy:any){

    }
    authenticate(userName,password,callback){
        this.proxy.post("login",{userName:userName,password:password},callback)
    }
    signup(userName,password,email,callback){
        this.proxy.post("add/new/user",{userName:userName,password:password,email:email},callback)
    }
}