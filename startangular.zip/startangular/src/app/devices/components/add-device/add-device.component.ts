import { Component, OnInit, EventEmitter,Output } from '@angular/core';
import {DeviceService} from '../../services/device.service'

@Component({
  selector: 'app-add-device',
  templateUrl: './add-device.component.html',
  styleUrls: ['./add-device.component.css']
})
export class AddDeviceComponent implements OnInit {
  deviceID;
  deviceName;
  constructor(public devicesServiceRef:DeviceService) { }

  ngOnInit() {
  }

  @Output()
  onNewDevice=new EventEmitter<any>();

  onAddDevice(){
    //debugger;
    let device={deviceID:this.deviceID,deviceName:this.deviceName}
    //this.onNewDevice.emit(device);
    this.devicesServiceRef.addNewDevice(device)
  }
}
