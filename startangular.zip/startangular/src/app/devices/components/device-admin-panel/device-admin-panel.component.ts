import { Component, OnInit } from '@angular/core';
import { ILogger } from 'src/app/services/ILogger.service';
import { DeviceService } from '../../services/device.service';

@Component({
  selector: 'app-device-admin-panel',
  templateUrl: './device-admin-panel.component.html',
  styleUrls: ['./device-admin-panel.component.css'],
  providers:[{provide:DeviceService,useClass:DeviceService}]
})
export class DeviceAdminPanelComponent implements OnInit {
  devicesList;
  constructor(public logger:ILogger) {
    this.devicesList = []
   }

  ngOnInit() {
  }

  onNewDeviceCallback(data){
    this.logger.write(data)
    this.devicesList.push(data)
  }
}
