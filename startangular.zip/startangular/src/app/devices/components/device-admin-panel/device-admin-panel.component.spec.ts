import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceAdminPanelComponent } from './device-admin-panel.component';

describe('DeviceAdminPanelComponent', () => {
  let component: DeviceAdminPanelComponent;
  let fixture: ComponentFixture<DeviceAdminPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceAdminPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceAdminPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
