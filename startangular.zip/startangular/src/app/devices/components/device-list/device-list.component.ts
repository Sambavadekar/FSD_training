import { Component, OnInit, Input } from '@angular/core';
import { DeviceService } from '../../services/device.service';
import { ILogger } from 'src/app/services/ILogger.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-device-list',
  templateUrl: './device-list.component.html',
  styleUrls: ['./device-list.component.css']
})
export class DeviceListComponent implements OnInit {

  @Input()
  devices
  
  subscriptionToken:Subscription;

  constructor(public logger:ILogger,public deviceServiceRef:DeviceService) { }

  ngOnInit() {
    this.subscriptionToken = this.deviceServiceRef.observableDeviceStream.subscribe((data)=>{
      this.logger.write("received data from subscription" + data)
      this.devices=data;
    })
  }

  ngOnDestroy() {
    this.subscriptionToken.unsubscribe()
  }
}
