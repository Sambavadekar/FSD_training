import {Subject} from 'rxjs'
export class DeviceService{
    devices=[];

    private deviceDataStream=new Subject<any>();

    //Observable ref
    observableDeviceStream=this.deviceDataStream.asObservable();

    addNewDevice(device){
        this.devices.push(device);
        //update Stream
        this.deviceDataStream.next(this.devices);
    }
}