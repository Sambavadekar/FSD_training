import {NgModule} from '@angular/core'
import {Routes,RouterModule} from '@angular/router'
import {MainComponent} from './components/main/main.component'
import { LoginComponent } from './accounts/components/login/login.component'
import { SignupComponent } from './accounts/components/signup/signup.component'
import { HomeComponent } from './home/components/home/home.component'

const appRoutes:Routes=[
    {path:'main',component:MainComponent,children:[
        {path:"login",component:LoginComponent},
        {path:"signup",component:SignupComponent}
    ]},
    {path:"",redirectTo:'main',pathMatch:'full'},
    {path:'home/:userName',component:HomeComponent}
]

@NgModule({
    imports:[RouterModule.forRoot(appRoutes)],
    exports:[RouterModule]
})
export class AppRoutingModule{

}