import {AppComponent} from './components/app/app.component'
import {BrowserModule} from '@angular/platform-browser'
import {NgModule} from '@angular/core'
import {AccountsModule} from './accounts/accounts.module'
import {LayoutModule} from './layout/layout.module'
import {ConsoleLoggerService} from './services/consoleLogger.service'
import {ILogger} from './services/ILogger.service'
import {DevicesModule} from './devices/devices.module';
import { MainComponent } from './components/main/main.component'
import {AppRoutingModule} from './app.routing.module'
import { HomeModule } from './home/home.module'

@NgModule({
    declarations:[AppComponent, MainComponent],
    bootstrap:[AppComponent],
    imports:[BrowserModule,AccountsModule,LayoutModule,DevicesModule,AppRoutingModule,HomeModule],
    providers:[{provide:ILogger,useClass:ConsoleLoggerService}]
    //providers:[{provide:"logger",useClass:ConsoleLoggerService}]
})
export class AppModule{

}